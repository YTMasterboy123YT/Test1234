---
name: Theme request
about: Suggest a theme to be added to Fluent Renewed
title: "Add THEMENAME Theme NOW! \U0001F47A"
labels: theme suggestion
assignees: ActualMasterOogway

---

**Context:**
Providing a clear image or sketch depicting the envisioned theme is imperative. It is highly recommended to accompany this with a script detailing the color scheme for the theme. An exemplar can be referenced [here](https://github.com/ActualMasterOogway/Fluent-Renewed/blob/main/src/Themes/Vynixu.luau).
